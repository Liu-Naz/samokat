URL_SERVICE = "https://0d8077c9-97c8-47ef-9358-14bda6625969.serverhub.praktikum-services.ru"
CREATE_ORDER = "/api/v1/orders"
GET_ORDER = "/api/v1/orders/track"